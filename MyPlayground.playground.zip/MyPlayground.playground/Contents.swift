//: Playground - noun: a place where people can play

import UIKit

//Unsafety
var str = "Hello, playground"

/*Variable tipada*/
var hola:String = "Hola"

let miConstane:Int = 30

var lvl:Int = 0 {
    willSet{
        print("El nivel de tu pokemons es \(lvl)")
    }
    didSet(oldValue){
        print("Tu pokemons ha subido de nivel \(oldValue) a \(lvl)")
    }
}

var ataque:Int = 0
var defensa:(Int){
    get{
        return (ataque + 5)
    }
    set(nuevoAtaque){ //Sería nuevaDefensa
        ataque = nuevoAtaque + 10
    }
}

print("Ataque:\(ataque)")
print("Defensa:\(defensa)") //Ya tengo el get
defensa = 10 //Hacemos un SET y me modifica ataque
print("ataque??\(ataque)")
print("DEF??\(defensa)")

var palabra = String()

palabra.append(" Usuario")

print(palabra)

print("\u{1F496}")

print("Hola 🤩")

var 👽 = 10
var 🧠 = 5
print(👽 + 🧠)

func 😿 (_ num:Int){
    print("Tu numero es el", num)
}
😿(10)

var string1 = "A"
var string2 = "A"

if (string1 == string2){
    
}
var hasHeader:Bool = true

var val:Int = (10 < 5) ? ataque : 20

print(val)

if 10 < 5 {
    print(ataque)
} else {
    print(20)
}
//Array de Int
var impares = [1,3,4,5]
//Array de String
let nombres = ["Juan","Tomas"]

impares.append(22)

var num = [Int]() //Array vacío
var num2: [Int] = []

var puntos = Array(repeating: 1, count: 10)

var p = Array(impares)

for pepe in impares {
    print(pepe)
}

let numero = impares[0]

var matrix:[[Int]] = [[1,2], [3,4,5]]

var ingredientes:Set = ["cacao","leche"]

ingredientes.insert("cacao")

var aeropuertos:Dictionary = ["String":"String"]

var airports = ["TKY":"Tokyo","BCN":"Bcn"]

//Añadir un elemento en el Diccionario
airports["MDR"] = "Madrid"

//Modificar un elemento en el Diccionario
airports["BCN"] = "Tomás"

//Recorrer un Diccionario por keys y values
for aeropuerto in airports {
    print("ID: \(aeropuerto.key), VAL:\(aeropuerto.value)")
}
//Recorrer un Diccionario por Llaves
for aeropuerto in airports.keys {
    print("ID: \(aeropuerto)")
}
//Recorrer un Diccionario por Values
for aeropuerto in airports.values {
    print("VAL: \(aeropuerto)")
}
/*Recorrer un Diccionario definiendo variables para
la key y el value */
for (aeropuertoCode,aeropuertoKey) in airports {
    print("Id.: \(aeropuertoCode), Val:\(aeropuertoKey)")
}

//Eliminar un elemento asignandolo a nil
airports["BCN"] = nil

for (aeropuertoCode,aeropuertoKey) in airports {
    print("Id.: \(aeropuertoCode), Val:\(aeropuertoKey)")
}

var letra:String? = "A"

if letra != nil {
   print(letra!)
}else{
    print("No soy un String")
}


